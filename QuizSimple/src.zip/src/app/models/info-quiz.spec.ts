import { InfoQuiz } from './info-quiz';

describe('InfoQuiz', () => {
  it('should create an instance', () => {
    expect(new InfoQuiz()).toBeTruthy();
  });
});
