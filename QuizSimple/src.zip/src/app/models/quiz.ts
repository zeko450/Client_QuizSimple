export class Quiz {
    quizId: number
    titre: string

    constructor(quizId: number, titre: string) {
        this.quizId = quizId
        this.titre = titre
    }
}
