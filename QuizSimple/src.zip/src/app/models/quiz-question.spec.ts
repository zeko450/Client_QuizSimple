import { QuizQuestion } from './quiz-question';

describe('QuizQuestion', () => {
  it('should create an instance', () => {
    expect(new QuizQuestion()).toBeTruthy();
  });
});
