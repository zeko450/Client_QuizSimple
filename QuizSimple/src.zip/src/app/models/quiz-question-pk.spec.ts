import { QuizQuestionPK } from './quiz-question-pk';

describe('QuizQuestionPK', () => {
  it('should create an instance', () => {
    expect(new QuizQuestionPK()).toBeTruthy();
  });
});
