import { Component, OnInit } from '@angular/core';
import { Question } from '../models/question';
import { Options } from '../models/options';
import { RestApiQuizService } from '../service/rest-api-quiz.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-passer-quiz',
  templateUrl: './passer-quiz.component.html',
  styleUrls: ['./passer-quiz.component.css']
})
export class PasserQuizComponent implements OnInit {

  ListeQuestion: Question[] = [];
  ListeOption: Options[] = [];
  id = 0;

  constructor(private restApi: RestApiQuizService, private router: ActivatedRoute, private router2: Router) {
    let idQuestion = this.router.snapshot.paramMap.get("id");

    if (idQuestion != null) {
      //Recupere les questions d'un quiz
      this.id = parseInt(idQuestion);
      this.restApi.getQuestionsForQuiz(this.id).subscribe((res) => {
        this.ListeQuestion = res;
        for (var tmp of this.ListeQuestion) {

          //Recupere les options d'une question donnée
          this.restApi.getOptionsForQuestion(tmp.questionId).subscribe((res) => {
            for (var tmp2 of res) {
              this.ListeOption.push(tmp2);
            }
          })
        }
      })
    }
  }

  ngOnInit(): void {
  }

  sauvegarder() {
    for (var tmp3 of this.ListeQuestion) {
     var choix =  document.getElementsByName(tmp3.questionId.toString())
      console.log(choix);
    }
  }
}
